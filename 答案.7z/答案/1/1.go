package main

import "fmt"

func main() {
	//大概的思路就是先对a[i]做一次排序，之后从询问时从大到小加起来算出最短睡眠时间
	var n, q, k, ma, mi int
	var b [1145]int
	fmt.Scanf("%d %d\n", &n, &q)
	ma = -1
	mi = 1145
	for i := 1; i <= n; i++ {
		fmt.Scanf("%d", &k)
		b[k]++
		if ma < k {
			ma = k
		}
		if mi > k {
			mi = k
		}
		//用的是桶排序，考虑到题目并没有强行要求排序后的结果存到另一个数组里，所以只记录数字出现个数即可
	}
	for i := 1; i <= q; i++ {
		fmt.Scanf("\n%d", &k)
		//同样的理由，没有必要一一记录询问的数字
		var s, h int = 0, 0
		for j := ma; j >= mi && s < k; j-- {
			for l := 1; l <= b[j]; l++ {
				s += j
				h++
				if s >= k {
					break
				}
				//从大到小加起来，如果到位了直接退出循环
			}
		}
		if s >= k {
			fmt.Println(h)
		} else {
			fmt.Println(-1)
		}
	}
}
