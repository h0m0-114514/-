package main

import "fmt"

func main() {
	//考虑到操作不限次数，贪心策略就是：尽可能把数组变得平均
	//这样思考的话，实际上甚至不需要实际记录数组，只需要记录输入的数字的综合即可
	var n, s int
	fmt.Scanf("%d\n", &n)
	for i := 1; i <= n; i++ {
		var k int
		fmt.Scanf("%d", &k)
		s += k
	}
	//这样考虑的话，事实上甚至不需要用循环结构来计算答案
	//计算，将公式套进去即可
	fmt.Printf("%d", (s-s/n*n)*(n-(s-s/n*n)))
}
